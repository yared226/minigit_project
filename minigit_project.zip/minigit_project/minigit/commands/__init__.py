"""
Package of MiniGit command‐handler modules.
Each module defines a cmd_<name>(args) function.
"""
