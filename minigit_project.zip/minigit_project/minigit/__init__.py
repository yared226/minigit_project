"""
MiniGit: A custom, minimal version control system.
"""

__version__ = "0.1.0"
